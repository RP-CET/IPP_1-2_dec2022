#
#The program will read "names.xlsx" in the "data_files" folder
#

import openpyxl

workbook = openpyxl.load_workbook(FIX_ME)
sheet=workbook["Sheet1"]


max_row = sheet.max_row 

#loop through every row
for i in range(FIX_ME, max_row + 1):
    
    #read cell
    first_name = sheet.cell(row=i, column=1).value
    last_name = sheet.cell(row=i, column=2).value
        
    print("First Name: FIX_ME \tLast Name: %s " % (first_name, FIX_ME))


