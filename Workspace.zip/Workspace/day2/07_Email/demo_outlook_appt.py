import win32com.client

outlook = win32com.client.Dispatch('outlook.application')
appt = outlook.CreateItem(1)
appt.Start = "2022-01-08 00:00" 
appt.Subject = "Online Sales Starts!"
appt.Duration = 60 
appt.Location = "Singapore"

#mail.Attachments.Add('c:\\sample.xlsx')
#mail.Attachments.Add('c:\\sample2.xlsx')
#mail.CC = 'somebody@company.com'
appt.MeetingStatus = 1

appt.Recipients.Add("rp.python.ipp@gmail.com")

appt.Save()
appt.Send()
print("Appt made")