import os
from PIL import Image, ImageFilter, ImageOps

files = os.listdir('img')

def watermark(im, mark, position):
	layer = Image.new("RGBA", im.size, (0,0,0,0))
	layer.paste(mark, position)
	return Image.composite(layer, im, layer)

mark = Image.open("img\\watermark.png")
mark = mark.resize((50,50))
mark.putalpha(128)


for file in files:
	if file.lower().endswith(".jpg"):
		im = Image.open("img/" + file)
		width, height = im.size 
		half_width = int(width*0.5)
		half_height = int(height*0.5)

		im.thumbnail((half_width, half_height), Image.ANTIALIAS)

		out = watermark(im, mark, (350,250))

		out.save("resized/" + file, "JPEG")

